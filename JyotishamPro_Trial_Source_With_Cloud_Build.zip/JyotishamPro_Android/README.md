# Jyotisham Pro — Trial Android project

This repository contains the initial native Android trial foundation for Jyotisham Pro.

## Included in this trial foundation
- Kotlin + Jetpack Compose Android application.
- Hindi/English interface switch (Hindi opens by default).
- Phone/tablet-friendly navigation and module catalogue.
- Birth-details entry screen.
- North Indian chart **layout preview only**.
- GitHub Actions workflow that builds a debug APK in the cloud and uploads it as an artifact.

## Important: what this is not
This is **not yet a complete professional Jyotish calculation product**. The chart is a visual preview; it does not calculate planetary placements. The listed Jyotish modules are navigation placeholders, not completed calculation engines. No prediction, dasha, divisional-chart, or Panchanga result should be treated as calculated by this trial.

## Build an APK without installing Android Studio on your phone

1. Create a GitHub account if you do not already have one.
2. Create a new repository and upload the contents of this project ZIP.
3. Open the repository's **Actions** tab.
4. Select **Build Jyotisham Pro Trial APK**.
5. Press **Run workflow** (or push to the `main` branch).
6. When the run finishes, open it and download the artifact named **JyotishamPro-Trial-APK**.
7. Extract the artifact ZIP; it contains `app-debug.apk`.

The APK is a debug build for trial/testing, not a signed production release. Android may ask you to approve installation from the browser/file manager. Only install APKs you built from source you trust.

## Build requirements
- JDK 17
- Android SDK Platform 35
- Android Gradle Plugin 8.10.1
- Gradle 8.11.1

## Professional calculation work still required
Before describing Jyotisham Pro as a complete or calculation-accurate product, the following must be implemented and independently tested:

1. Select an ephemeris engine and review its licensing terms for the intended distribution model.
2. Implement historical timezone and daylight-saving-time handling, plus confirmed birth coordinates.
3. Implement sidereal planetary positions and configurable ayanamsha (including clearly specified Lahiri/Raman/KP options).
4. Validate Lagna, Bhava, nakshatra/pada, Rahu/Ketu and planetary longitudes against trusted reference charts.
5. Implement and test Shodasha Varga, Vimshottari and other dasha systems, Shadbala, Ashtakavarga, Panchanga and other promised modules.
6. Add durable local profile storage, backup/export, and Hindi/English PDF report generation.
7. Add calculation audit details: ephemeris version, settings, timezone, coordinates and precision.

Astronomical calculations can be tested against reference data. Astrological interpretations and predictions are traditional belief-based systems and are not scientifically established.

## Language quality
Hindi labels are initial interface text. Full Hindi explanations, classical quotations, glossary entries and report templates still need specialist editorial review.
