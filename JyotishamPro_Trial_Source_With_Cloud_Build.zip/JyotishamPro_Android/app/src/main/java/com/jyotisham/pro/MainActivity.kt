package com.jyotisham.pro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jyotisham.pro.ui.theme.JyotishamTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JyotishamTheme { JyotishamApp() } }
    }
}

private enum class Page { HOME, CHARTS, PROFILES, TOOLS, SETTINGS }
private enum class Language { EN, HI }

private data class JyotishModule(val en: String, val hi: String, val detailEn: String, val detailHi: String)

private val modules = listOf(
    JyotishModule("Birth chart", "जन्म कुण्डली", "D1 • Lagna • Bhava • Planetary positions", "डी१ • लग्न • भाव • ग्रह स्थिति"),
    JyotishModule("Divisional charts", "षोडशवर्ग", "D1–D60 • Shodasha Varga", "डी१ से डी६० • षोडशवर्ग"),
    JyotishModule("Vimshottari Dasha", "विंशोत्तरी दशा", "Mahadasha • Antardasha • Pratyantardasha", "महादशा • अन्तर्दशा • प्रत्यन्तर्दशा"),
    JyotishModule("Shadbala", "षड्बल", "Six-fold planetary strength", "ग्रहों का छह प्रकार का बल"),
    JyotishModule("Ashtakavarga", "अष्टकवर्ग", "Bhinna • Sarva • Prastara", "भिन्न • सर्व • प्रस्तार"),
    JyotishModule("Yogas", "योग", "Raja • Dhana • Pancha Mahapurusha", "राजयोग • धनयोग • पञ्चमहापुरुष योग"),
    JyotishModule("Jaimini", "जैमिनी", "Chara Karaka • Arudha • Rashi Drishti", "चरकारक • आरूढ़ • राशि दृष्टि"),
    JyotishModule("KP Astrology", "कृष्णमूर्ति पद्धति", "Cusps • Sub-lords • Significators", "कसप • उप-स्वामी • कारक"),
    JyotishModule("Panchanga", "पञ्चाङ्ग", "Tithi • Vara • Nakshatra • Yoga • Karana", "तिथि • वार • नक्षत्र • योग • करण"),
    JyotishModule("Muhurta", "मुहूर्त", "Traditional electional astrology", "परम्परागत मुहूर्त विचार"),
    JyotishModule("Gochar", "गोचर", "Transit positions and timelines", "ग्रह गोचर एवं समयरेखा"),
    JyotishModule("Varshaphala", "वर्षफल", "Solar return • Tajika • Mudda Dasha", "सौर वापसी • ताजिक • मुद्दा दशा"),
    JyotishModule("Prashna", "प्रश्न ज्योतिष", "Horary chart workspace", "प्रश्न कुण्डली कार्यक्षेत्र"),
    JyotishModule("Compatibility", "कुण्डली मिलान", "Ashtakoota • Dashakoota", "अष्टकूट • दशाकूट"),
    JyotishModule("Reports", "प्रतिवेदन", "Print-ready PDF reports", "मुद्रण योग्य PDF प्रतिवेदन"),
    JyotishModule("Classical library", "शास्त्रीय ग्रन्थालय", "References and source notes", "सन्दर्भ एवं स्रोत टिप्पणियाँ")
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun JyotishamApp() {
    var language by remember { mutableStateOf(Language.HI) }
    var page by remember { mutableStateOf(Page.HOME) }
    var selectedModule by remember { mutableStateOf<JyotishModule?>(null) }
    val hi = language == Language.HI

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("JYOTISHAM PRO", fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                        Text(if (hi) "वैदिक ज्योतिष कार्यक्षेत्र" else "VEDIC ASTROLOGY WORKSPACE",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                actions = {
                    TextButton(onClick = { language = if (hi) Language.EN else Language.HI }) {
                        Text(if (hi) "EN" else "हिन्दी", fontWeight = FontWeight.Bold)
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = page == Page.HOME, onClick = { page = Page.HOME; selectedModule = null },
                    icon = { Icon(Icons.Default.Home, null) }, label = { Text(if (hi) "मुख्य" else "Home") })
                NavigationBarItem(selected = page == Page.CHARTS, onClick = { page = Page.CHARTS; selectedModule = null },
                    icon = { Icon(Icons.Default.GridView, null) }, label = { Text(if (hi) "कुण्डली" else "Charts") })
                NavigationBarItem(selected = page == Page.PROFILES, onClick = { page = Page.PROFILES; selectedModule = null },
                    icon = { Icon(Icons.Default.People, null) }, label = { Text(if (hi) "जातक" else "Profiles") })
                NavigationBarItem(selected = page == Page.TOOLS, onClick = { page = Page.TOOLS; selectedModule = null },
                    icon = { Icon(Icons.Default.AutoAwesome, null) }, label = { Text(if (hi) "उपकरण" else "Tools") })
                NavigationBarItem(selected = page == Page.SETTINGS, onClick = { page = Page.SETTINGS; selectedModule = null },
                    icon = { Icon(Icons.Default.Settings, null) }, label = { Text(if (hi) "सेटिंग" else "Settings") })
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            if (selectedModule != null) {
                ModuleDetail(selectedModule!!, hi, onBack = { selectedModule = null })
            } else when (page) {
                Page.HOME -> HomeScreen(hi, onModule = { selectedModule = it }, onProfiles = { page = Page.PROFILES })
                Page.CHARTS -> ChartsScreen(hi, onModule = { selectedModule = it })
                Page.PROFILES -> ProfilesScreen(hi)
                Page.TOOLS -> ToolsScreen(hi, onModule = { selectedModule = it })
                Page.SETTINGS -> SettingsScreen(hi, onLanguage = { language = it })
            }
        }
    }
}

@Composable
private fun HomeScreen(hi: Boolean, onModule: (JyotishModule) -> Unit, onProfiles: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(if (hi) "नमस्ते" else "Welcome to Jyotisham Pro",
                style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(if (hi) "आपका व्यावसायिक ज्योतिष कार्यक्षेत्र" else "Your professional Vedic astrology workspace")
            Button(onClick = onProfiles) {
                Icon(Icons.Default.PersonAdd, null); Spacer(Modifier.width(8.dp))
                Text(if (hi) "नया जातक जोड़ें" else "Add birth profile")
            }
        }
    }
    Spacer(Modifier.height(18.dp))
    SectionTitle(if (hi) "ज्योतिष मॉड्यूल" else "Jyotish modules")
    ModuleGrid(hi, onModule)
    Spacer(Modifier.height(18.dp))
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(if (hi) "गणना-शुद्धता" else "Calculation integrity",
                fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            Text(if (hi)
                "ग्रहों की वास्तविक स्थिति, अयनांश, दशा और वर्ग कुण्डली की गणनाएँ प्रमाणित पंचांग/एफेमेरिस से जोड़ने और परीक्षण करने के बाद ही प्रकाशित होंगी।"
            else
                "Planetary positions, ayanamsha, dasha and divisional-chart calculations will be released only after integration with a verified ephemeris and independent test cases.")
        }
    }
}

@Composable
private fun ChartsScreen(hi: Boolean, onModule: (JyotishModule) -> Unit) {
    SectionTitle(if (hi) "कुण्डली कार्यक्षेत्र" else "Chart workspace")
    Text(if (hi) "किसी जातक का चयन करें या नया जन्म विवरण जोड़ें।" else "Select a profile or add new birth details.",
        color = MaterialTheme.colorScheme.onSurfaceVariant)
    Spacer(Modifier.height(12.dp))
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(if (hi) "उत्तर भारतीय शैली — नमूना प्रारूप" else "North Indian style — layout preview",
                fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(12.dp))
            NorthIndianChartPreview()
            Spacer(Modifier.height(8.dp))
            Text(if (hi) "यह केवल चार्ट का दृश्य प्रारूप है; इसमें ग्रह स्थितियाँ अभी गणना नहीं की गई हैं।"
                else "This is a visual chart layout preview; planetary placements have not yet been calculated.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    Spacer(Modifier.height(16.dp))
    modules.take(3).forEach { ModuleRow(it, hi) { onModule(it) } }
}

@Composable
private fun NorthIndianChartPreview() {
    val lineColor = MaterialTheme.colorScheme.outline
    Canvas(Modifier.fillMaxWidth().aspectRatio(1f).padding(8.dp)) {
        val w = size.width; val h = size.height
        val p = Path().apply {
            moveTo(w/2, 0f); lineTo(w, h/2); lineTo(w/2, h); lineTo(0f, h/2); close()
            moveTo(0f, 0f); lineTo(w, h); moveTo(w, 0f); lineTo(0f, h)
            moveTo(w/2, 0f); lineTo(w/4, h/4); lineTo(0f, h/2)
            moveTo(w/2, 0f); lineTo(w*3/4, h/4); lineTo(w, h/2)
            moveTo(w, h/2); lineTo(w*3/4, h*3/4); lineTo(w/2, h)
            moveTo(w/2, h); lineTo(w/4, h*3/4); lineTo(0f, h/2)
        }
        drawPath(p, lineColor, style = Stroke(width = 2.dp.toPx()))
    }
}

@Composable
private fun ProfilesScreen(hi: Boolean) {
    var name by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }
    var time by remember { mutableStateOf("") }
    var place by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(false) }
    SectionTitle(if (hi) "जातक प्रबन्धक" else "Birth profile manager")
    Text(if (hi) "जन्म विवरण" else "Birth details", fontWeight = FontWeight.SemiBold)
    OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text(if (hi) "नाम" else "Name") }, singleLine = true)
    OutlinedTextField(date, { date = it }, Modifier.fillMaxWidth(), label = { Text(if (hi) "जन्म तिथि (YYYY-MM-DD)" else "Birth date (YYYY-MM-DD)") }, singleLine = true)
    OutlinedTextField(time, { time = it }, Modifier.fillMaxWidth(), label = { Text(if (hi) "जन्म समय (HH:MM)" else "Birth time (HH:MM)") }, singleLine = true)
    OutlinedTextField(place, { place = it }, Modifier.fillMaxWidth(), label = { Text(if (hi) "जन्म स्थान" else "Birth place") }, singleLine = true)
    Spacer(Modifier.height(10.dp))
    Button(onClick = { saved = name.isNotBlank() && date.isNotBlank() && time.isNotBlank() && place.isNotBlank() },
        modifier = Modifier.fillMaxWidth()) { Text(if (hi) "विवरण जाँचें" else "Validate details") }
    if (saved) Text(if (hi) "विवरण भरे गए हैं। स्थायी स्थानीय संग्रह और पंचांग गणना अगले चरण में जोड़ी जाएगी।"
        else "Details entered. Persistent local storage and ephemeris calculation are the next implementation step.",
        color = MaterialTheme.colorScheme.primary)
    Spacer(Modifier.height(12.dp))
    Text(if (hi) "समय क्षेत्र और निर्देशांक की पुष्टि आवश्यक होगी।" else "Time zone and geographic coordinates must be confirmed before chart calculation.",
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun ToolsScreen(hi: Boolean, onModule: (JyotishModule) -> Unit) {
    SectionTitle(if (hi) "सभी ज्योतिष उपकरण" else "All Jyotish tools")
    ModuleGrid(hi, onModule)
}

@Composable
private fun SettingsScreen(hi: Boolean, onLanguage: (Language) -> Unit) {
    SectionTitle(if (hi) "सेटिंग" else "Settings")
    Text(if (hi) "भाषा / Language", fontWeight = FontWeight.SemiBold)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = { onLanguage(Language.HI) }) { Text("हिन्दी") }
        OutlinedButton(onClick = { onLanguage(Language.EN) }) { Text("English") }
    }
    HorizontalDivider(Modifier.padding(vertical = 12.dp))
    Text(if (hi) "संस्करण 0.1.0 • प्रारम्भिक कार्यशील आधार" else "Version 0.1.0 • Initial working foundation")
    Text(if (hi) "यह संस्करण अभी पूर्ण ज्योतिषीय गणना या भविष्यवाणी का दावा नहीं करता।"
        else "This build does not yet claim complete astrological calculations or predictions.",
        color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun ModuleDetail(module: JyotishModule, hi: Boolean, onBack: () -> Unit) {
    TextButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null); Spacer(Modifier.width(6.dp)); Text(if (hi) "वापस" else "Back") }
    SectionTitle(if (hi) module.hi else module.en)
    Text(if (hi) module.detailHi else module.detailEn, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Spacer(Modifier.height(16.dp))
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(if (hi) "मॉड्यूल स्थिति" else "Module status", fontWeight = FontWeight.Bold)
            Text(if (hi)
                "यह मॉड्यूल मुख्य नेविगेशन और उत्पाद संरचना में सम्मिलित है। वास्तविक गणना, परिणाम तालिकाएँ, व्याख्या और परीक्षण इसके पृथक विकास चरण में जोड़े जाएँगे।"
            else
                "This module is registered in the product structure. Its calculation logic, result tables, interpretations and validation tests will be implemented in its dedicated development stage.")
        }
    }
}

@Composable
private fun ModuleGrid(hi: Boolean, onModule: (JyotishModule) -> Unit) {
    LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.heightIn(max = 1200.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp),
        userScrollEnabled = false) {
        items(modules) { module ->
            Card(Modifier.fillMaxWidth().clickable { onModule(module) }) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(if (hi) module.hi else module.en, fontWeight = FontWeight.Bold)
                    Text(if (hi) module.detailHi else module.detailEn, style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                }
            }
        }
    }
}

@Composable
private fun ModuleRow(module: JyotishModule, hi: Boolean, onClick: () -> Unit) {
    ListItem(
        headlineContent = { Text(if (hi) module.hi else module.en) },
        supportingContent = { Text(if (hi) module.detailHi else module.detailEn) },
        trailingContent = { Icon(Icons.Default.ChevronRight, null) },
        modifier = Modifier.clickable { onClick() }
    )
    HorizontalDivider()
}

@Composable
private fun SectionTitle(title: String) {
    Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(bottom = 10.dp))
}
