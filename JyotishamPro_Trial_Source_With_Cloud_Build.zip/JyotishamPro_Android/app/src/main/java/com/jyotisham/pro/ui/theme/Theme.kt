package com.jyotisham.pro.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val JyotishColors = lightColorScheme(
    primary = Color(0xFF79552D),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFF1E5D3),
    onPrimaryContainer = Color(0xFF2E2114),
    secondary = Color(0xFF52645B),
    background = Color(0xFFFAF8F4),
    surface = Color(0xFFFFFDF9),
    outline = Color(0xFF8C806F)
)

@Composable
fun JyotishamTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = JyotishColors, content = content)
}
